package com.imooc.reflect;

import com.imooc.reflect.entity.Employee;

import java.lang.reflect.Constructor;

public class getDeclaredSample {
    public static void main(String[] args) {
        Class employeeClass = Class.forName("com.imooc.reflect.entity.Employee");
        Constructor constructor = employeeClass.getConstructor(new Class[]{
                Integer.class,String.class,Float.class,String.class
        });
        Employee employee
    }
}
